Sample App

Sample Python Flask application to showcase the steps of building and running a web server with Docker.

Docker: https://www.docker.com/
Flask documentation: https://flask.palletsprojects.com/en/1.1.x/
